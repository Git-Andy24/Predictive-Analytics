# Topsis-Anerudh-102203042

This package implements the TOPSIS method for multi-criteria decision analysis.

## Installation
```sh
pip install Topsis-Anerudh-102203042
